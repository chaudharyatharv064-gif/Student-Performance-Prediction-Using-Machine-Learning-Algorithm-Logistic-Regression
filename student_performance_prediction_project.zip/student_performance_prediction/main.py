"""
Student Performance Prediction
Educational demo project: predicts pass/fail from study hours, attendance,
and previous score. The included dataset is small and illustrative, not real
student records and not suitable for consequential decisions.
"""
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib

DATA_PATH = Path(__file__).with_name("student_data.csv")
MODEL_PATH = Path(__file__).with_name("student_pass_model.joblib")
FEATURES = ["study_hours", "attendance_percent", "previous_score"]

def main():
    data = pd.read_csv(DATA_PATH)
    X = data[FEATURES]
    y = data["passed"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    model = make_pipeline(StandardScaler(), LogisticRegression(random_state=42))
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    print("STUDENT PERFORMANCE PREDICTION")
    print("-" * 35)
    print(f"Test accuracy: {accuracy_score(y_test, predictions):.2%}")
    print("\nClassification report:")
    print(classification_report(y_test, predictions, zero_division=0))
    print("Confusion matrix:")
    print(confusion_matrix(y_test, predictions))

    joblib.dump(model, MODEL_PATH)
    print(f"\nSaved trained model to: {MODEL_PATH.name}")

    sample = pd.DataFrame(
        [[5, 75, 68]], columns=FEATURES
    )
    result = int(model.predict(sample)[0])
    print("\nExample student: 5 study hours/day, 75% attendance, previous score 68")
    print("Prediction:", "Likely to pass" if result == 1 else "May need more support")

if __name__ == "__main__":
    main()
