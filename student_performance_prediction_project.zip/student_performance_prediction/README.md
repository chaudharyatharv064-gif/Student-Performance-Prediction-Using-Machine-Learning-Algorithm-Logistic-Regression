# Student Performance Prediction (ML Project)

## Project title
**Student Performance Prediction Using Machine Learning**

## Objective
This beginner-level machine learning project demonstrates how a classification model can estimate whether a student is likely to pass using:
- Study hours per day
- Attendance percentage
- Previous score

The included CSV is a small, illustrative sample dataset created for learning. It is not real student data and the model should not be used to make real academic decisions.

## Algorithm
- Logistic Regression
- StandardScaler preprocessing
- Train/test split
- Evaluation with accuracy, classification report, and confusion matrix

## Project files
- `main.py` — loads data, trains/evaluates the model, saves it, and demonstrates a prediction
- `student_data.csv` — sample dataset
- `requirements.txt` — Python dependencies

## How to run
Use Python 3.10 or newer.

1. Download or clone this repository.
2. Open a terminal in the project folder.
3. (Recommended) create and activate a virtual environment:
   - Windows: `python -m venv .venv` then `.venv\Scripts\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install dependencies:
   `pip install -r requirements.txt`
5. Run:
   `python main.py`

The script prints evaluation results and saves `student_pass_model.joblib`.

## Example
The script also predicts an example profile with 5 study hours/day, 75% attendance, and a previous score of 68. Results may vary with the sample split and should not be treated as a reliable real-world prediction.

## Future improvements
- Use a larger, ethically collected dataset
- Add a simple Streamlit user interface
- Compare Logistic Regression, Decision Tree, and Random Forest
- Add cross-validation and more robust evaluation

## GitHub submission
Create a new public repository named `student-performance-prediction`, upload these project files, and copy the repository URL into your university's shared sheet. Do not submit a made-up repository URL: the link only exists after you create the repository and upload the files.
